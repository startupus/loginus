# 🧮 Умный калькулятор с Backend интеграцией

Продвинутая версия калькулятора с полной интеграцией системы расширений Loginus.

## ✨ Возможности

### 1️⃣ **Backend интеграция**
- ✅ Отправка событий в EventBus при каждом вычислении
- ✅ Логирование ошибок в системе событий
- ✅ Получение токена авторизации из localStorage
- ✅ Проверка подключения к backend каждые 30 секунд

### 2️⃣ **Отправляемые события**
- `CALCULATOR_CALCULATION_DONE` - успешное вычисление
- `CALCULATOR_ERROR` - ошибка вычисления
- `CALCULATOR_HISTORY_SAVED` - сохранение истории

### 3️⃣ **Подписка на события**
- `USER_SETTINGS_UPDATED` - обновление настроек пользователя

### 4️⃣ **Коммуникация с родительским окном**
- Отправка событий через `postMessage`
- Получение настроек от родительского приложения

### 5️⃣ **Сохранение истории**
- История хранится в `localStorage`
- Последние 10 вычислений
- Отображение времени операции

## 🔌 API интеграция

```javascript
// Отправка события в backend
await fetch('http://localhost:3004/api/v2/events/emit', {
    method: 'POST',
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        eventName: 'CALCULATOR_CALCULATION_DONE',
        data: {
            expression: '2 + 2',
            result: '4',
            pluginId: 'calculator-advanced',
            timestamp: new Date().toISOString()
        }
    })
});
```

## 📦 Установка

1. Создайте ZIP архив с файлами:
   - `manifest.json` - манифест плагина
   - `index.html` - frontend UI
   - `backend/` - **backend код плагина**
     - `calculator.controller.ts` - контроллер API
     - `calculator.module.ts` - NestJS модуль
     - `README.md` - инструкции по установке backend
   - `README.md` - документация

2. Загрузите через админ панель: `/ru/admin/plugins/upload`

3. **Backend код автоматически установится** в `src/plugins/calculator-advanced/`

4. Создайте пункт меню для плагина в: `/ru/admin/menu-settings`

## 🔧 Backend код

Плагин включает **полный backend код**:
- ✅ Контроллер для `/api/v2/calculator/calculate`
- ✅ NestJS модуль для регистрации
- ✅ Интеграция с EventBus
- ✅ Валидация и безопасное вычисление

**При загрузке плагина:**
1. Frontend код → `uploads/plugins/calculator-advanced/`
2. Backend код → `src/plugins/calculator-advanced/`

**Примечание:** Для активации backend кода используется существующий `CalculatorController` в `CoreModule`, который уже зарегистрирован и работает сразу после загрузки плагина.

## 🎯 Проверка работы

### **В браузере:**
1. Откройте калькулятор через меню
2. Выполните вычисление (например, `2 + 2`)
3. Проверьте лог событий внизу калькулятора
4. Должны увидеть: "✅ Событие отправлено: CALCULATOR_CALCULATION_DONE"

### **В backend логах:**
```bash
docker logs loginus-api-new | grep "CALCULATOR"
```

Должны увидеть:
```
[EventBusService] Event dispatched: CALCULATOR_CALCULATION_DONE
[EventLoggerService] Event logged: CALCULATOR_CALCULATION_DONE
```

### **В базе данных:**
```sql
SELECT * FROM event_logs WHERE event_name LIKE 'CALCULATOR%' ORDER BY created_at DESC LIMIT 5;
```

## 🔍 Индикаторы состояния

- 🟢 **Зелёная точка** - подключено к backend
- 🔴 **Красная точка** - нет подключения

## 📊 Лог событий

Внизу калькулятора отображаются последние 5 событий:
- ✅ Успешные операции
- ❌ Ошибки
- 📤 Отправка данных родителю
- ⚙️ Получение настроек

## 🧪 Тестирование системы плагинов

Этот плагин проверяет:
1. ✅ Загрузку и извлечение `.zip` архива
2. ✅ Парсинг `manifest.json`
3. ✅ Рендеринг в iframe
4. ✅ Отправку событий в EventBus
5. ✅ Логирование в БД
6. ✅ Коммуникацию через postMessage
7. ✅ Работу с localStorage
8. ✅ Авторизацию через JWT токен

## 📝 Структура событий

```typescript
interface CalculationEvent {
  eventName: 'CALCULATOR_CALCULATION_DONE';
  data: {
    expression: string;      // "2 + 2"
    result: string;          // "4"
    pluginId: string;        // "calculator-advanced"
    timestamp: string;       // ISO 8601
  };
}
```

## 🚀 Дальнейшее развитие

- [ ] Добавить сохранение истории в backend
- [ ] Реализовать синхронизацию между устройствами
- [ ] Добавить экспорт истории в CSV/JSON
- [ ] Поддержка научных функций
- [ ] Темы оформления (light/dark)

