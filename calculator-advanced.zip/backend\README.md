# Backend код для плагина calculator-advanced

## 📁 Структура

```
calculator-plugin-advanced/
├── backend/
│   ├── calculator.controller.ts  # Контроллер для API
│   └── calculator.module.ts       # NestJS модуль
├── index.html                     # Frontend UI
└── manifest.json                  # Манифест плагина
```

## 🔧 Установка

При загрузке плагина через админ панель:

1. **Backend код копируется** в `src/plugins/calculator-advanced/`
2. **Frontend код** остаётся в `uploads/plugins/calculator-advanced/`

## ⚠️ ВАЖНО: Регистрация модуля

После установки плагина backend код будет скопирован, но для его активации нужно:

### **Вариант 1: Использовать существующий контроллер (рекомендуется)**

Backend код уже зарегистрирован в `CoreModule`:
- `CalculatorController` в `backend/src/core/extensions/calculator.controller.ts`
- Уже подключён к `/api/v2/calculator/calculate`

**Плагин будет работать сразу после загрузки!**

### **Вариант 2: Динамическая регистрация (требует доработки)**

Для динамической регистрации модуля из плагина нужно:
1. Скомпилировать TypeScript код в JavaScript
2. Использовать динамические модули NestJS
3. Зарегистрировать модуль через `PluginModuleLoaderService`

**Требует перезапуска приложения или использования динамических модулей.**

## 📝 Текущая реализация

Сейчас используется **Вариант 1** - существующий `CalculatorController` в `CoreModule`.

Backend код в архиве плагина служит как:
- ✅ Документация API плагина
- ✅ Резервная копия логики
- ✅ Пример для других плагинов

## 🚀 Использование

После загрузки плагина:
1. Frontend вызывает `/api/v2/calculator/calculate`
2. Backend обрабатывает запрос через существующий `CalculatorController`
3. События логируются в EventBus

**Всё работает без дополнительной настройки!**

